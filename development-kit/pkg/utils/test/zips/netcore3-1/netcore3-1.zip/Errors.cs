namespace NetCoreVulnerabilities
{
    public class Errors
    {
        public void NotUsedVar()
        {
            var neverUsedVar1 = "";
        }
        
        public void NotUsedVar2()
        {
            var neverUsedVar2 = "";
        }
    }
}
